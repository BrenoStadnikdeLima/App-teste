package com.example.sadepre;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class regiao extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela3);
    }
}