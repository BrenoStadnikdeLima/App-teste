package com.example.sadepre;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class garagemadmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.telaadmin3);
    }
}